package utility;

public class Constant {
	public static final String filePath = System.getProperty("user.dir")+"\\TestData";
	public static final String fileName = "FR.xls";
	public static String chromeDriverPath = System.getProperty("user.dir")+"\\drivers\\chromedriver.exe";
	public static String geckoDriverPath = System.getProperty("user.dir")+"\\drivers\\geckodriver.exe";
}
